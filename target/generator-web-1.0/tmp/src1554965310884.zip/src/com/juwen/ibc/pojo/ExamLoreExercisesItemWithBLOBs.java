package com.juwen.ibc.pojo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value="ExamLoreExercisesItemWithBLOBs" ,description="���Դ�ٶ�Ӧ���½ڱ�")
public class ExamLoreExercisesItemWithBLOBs extends ExamLoreExercisesItem {
    @ApiModelProperty(value="����")
    private String title;

    @ApiModelProperty(value="����")
    private String description;
}