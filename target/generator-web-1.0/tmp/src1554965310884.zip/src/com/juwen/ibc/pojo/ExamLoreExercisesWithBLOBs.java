package com.juwen.ibc.pojo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value="ExamLoreExercisesWithBLOBs" ,description="���Դ�ٱ�")
public class ExamLoreExercisesWithBLOBs extends ExamLoreExercises {
    @ApiModelProperty(value="����")
    private String title;

    @ApiModelProperty(value="����")
    private String description;
}