package com.juwen.ibc.dao;

import com.juwen.ibc.pojo.RoleFunctions;

/**
* Created by Mybatis Generator on 2019/04/11
*/
public interface IRoleFunctionsDAO {
    int insert(RoleFunctions record);

    int insertSelective(RoleFunctions record);
}